package lk.cwk2.SlotMachine;
import java.net.URL;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import model.Symbol;




public class GameController {
	public List<Reel> reelList;
	private Competitor competitor;
	public Thread reelThread1;//creating thread for first reel
	public Thread reelThread2;//creating thread for second reel
	public Thread reelThread3;//creating thread for third reel
	private Symbol currentSymbolreel1;
	private Symbol currentSymbolreel2;
	private Symbol currentSymbolreel3;
	private int matchigSymbolValue;
	private boolean isTie;

	public GameController() {
		reelList = new ArrayList<Reel>();

		reelList.add(new Reel());
		reelList.add(new Reel());
		reelList.add(new Reel());

		competitor = new Competitor(null);
	}


	public int addCoin(int val) {
		competitor.setCredit(val);
		return competitor.getCredit();
	}

	
	public int addBet(int amount) {
		// checks whether player has enough amount of coins
		if (competitor.getCredit() >= amount) {
			competitor.setBetAmount(amount);
			competitor.setCredit(-amount);
		} else {
			JOptionPane.showMessageDialog(null, "No credits to bet Please buy Coins",
					"Empty Wallet", JOptionPane.ERROR_MESSAGE);
		}
		return competitor.getBetAmount();
	}


	public int resetBet() {
		competitor.setCredit(competitor.getBetAmount());
		competitor.setBetAmount(-competitor.getBetAmount());
		return competitor.getCredit();
	}

	// getter method of the player variable
	public Competitor getPlayer() {
		return competitor;
	}

	
	public void startNewGame(String playerName) {
		this.competitor = new Competitor(playerName);
	}

	public double calculateNettedAmount() {
		return (competitor.getBetAmount() / (competitor.getBetAmount() * 1.0 + competitor.getCredit())) * 100;
	}

	
	public int calculateWonCredits() {
		return competitor.getBetAmount() * matchigSymbolValue;
	}

	
	public int saveGameResult() {
		int wonCredits = 0;
		// Lost = 0, Tie = -1
		boolean isWon = isWon();
		if (isWon) {
			wonCredits = calculateWonCredits();
			competitor.getWinners().add((double) wonCredits);
			competitor.setBetAmount(-competitor.getBetAmount());
		} else if (!isWon && isTie) {
			wonCredits = -1;
			competitor.getWinners().add((double) wonCredits);
			isTie = false;
		} else {
			competitor.getLoosers().add((double) -competitor.getBetAmount());
			competitor.setBetAmount(-competitor.getBetAmount());
		}

		return wonCredits;
	}

	
	public boolean isWon() {

		
		int[] result1 = currentSymbolreel1.compareValues(currentSymbolreel2);
		int[] result2 = currentSymbolreel1.compareValues(currentSymbolreel3);
		int[] result3 = currentSymbolreel3.compareValues(currentSymbolreel2);

		// finding the matching symbol if any
		if (result1[0] == 1 && result2[0] == 1 && result3[0] == 1) {
			if (result1[0] == 1) {
				matchigSymbolValue = result1[1];
			} else if (result2[0] == 1) {
				matchigSymbolValue = result2[1];
			} else if (result3[0] == 1) {
				matchigSymbolValue = result3[1];
			}
			return true;
		} else if ((result1[0] == 1 || result2[0] == 1 || result3[0] == 1)
				&& !(result1[0] == 1 && result2[0] == 1 && result3[0] == 1)) {
			isTie = true;
			return false;
		} else {
			return false;
		}
	}

	public ImageIcon createIcon(String path) {
		URL url = getClass().getResource(path);
	
		if (url == null) { // if the image is not found
			System.err.println("error opening: " + path);
		}
		ImageIcon icon = new ImageIcon(url);
		return icon;
	}

	// getter method of the currentSymbol variable of the first reel
	public Symbol getCurrentSymbol_reel1() {
		return currentSymbolreel1;
	}

	// setter method of the currentSymbol variable of the first reel
	public void setCurrentSymbol_reel1(Symbol symbol) {
		this.currentSymbolreel1 = symbol;
	}

	// getter method of the currentSymbol variable of the second reel
	public Symbol getCurrentSymbol_reel2() {
		return currentSymbolreel2;
	}

	// setter method of the currentSymbol variable of the second reel
	public void setCurrentSymbol_reel2(Symbol symbol) {
		this.currentSymbolreel2 = symbol;
	}

	// getter method of the currentSymbol variable of the third reel
	public Symbol getCurrentSymbol_reel3() {
		return currentSymbolreel3;
	}

	// setter method of the currentSymbol variable of the third reel
	public void setCurrentSymbol_reel3(Symbol currentSymbolreel3) {
		this.currentSymbolreel3 = currentSymbolreel3;
	}


	

}
