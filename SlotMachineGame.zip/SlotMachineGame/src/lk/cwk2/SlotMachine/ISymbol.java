package lk.cwk2.SlotMachine;

public interface ISymbol {
	//this interface is used for code re usability purposes
	
	void setImage(String img);

	String getImage();

	void setValue(int v);

	int getValue();
}
