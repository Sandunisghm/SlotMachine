package lk.cwk2.SlotMachine;

import javax.swing.SwingUtilities;



public class Run {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new SlotMachine_Interface());


	}

}
