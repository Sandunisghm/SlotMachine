package lk.cwk2.SlotMachine;


public class Symbol implements ISymbol {
	private String imgLocation;
	private int value;

	
	public Symbol(String imageName, int value) {
		imgLocation = "../img/" + imageName;
		this.value = value;
	}

	
	public int[] compareValues(Symbol symbol) {
		int[] payoff = new int[2];
		payoff[1] = value;
		if (this.value == symbol.getValue()) {
			payoff[0] = 1;
		} else {
			payoff[0] = 0;
		}
		return payoff;
	}

	
	@Override
	public void setImage(String imageName) {
		imgLocation = "../img/" + imageName;
	}

	@Override
	public String getImage() {
	//implementation of ISymbol methods
		return imgLocation;
	}

	@Override
	public void setValue(int val) {
	//implementation of ISymbol methods
		value = val;

	}

	@Override
	public int getValue() {
	//implementation of ISymbol methods
		return value;
	}

}
