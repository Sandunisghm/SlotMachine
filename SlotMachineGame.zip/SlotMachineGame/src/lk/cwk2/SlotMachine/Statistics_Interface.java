package lk.cwk2.SlotMachine;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.border.Border;



public class Statistics_Interface extends JFrame {
	private JButton btnSave;
	private JLabel lblPlayerName;
	private JLabel lblTotalWIns;
	private JLabel lblTotalLoses;
	private JLabel lblAverageNettedAmount;
	private JProgressBar progressBar;

	private JPanel buttonAreaPanel;
	private JPanel displayArePanel;
	private JPanel panel;

	private Statistics controller;

	
	public Statistics_Interface(Competitor competitor) {
		super("Game Statistics");
		controller = new Statistics(competitor);

		
		prepareGUI();
		addListeners();
	}

	private void prepareGUI() {
		setLayout(new BorderLayout());

		lblPlayerName = new JLabel("Player Name: " + controller.getPlayer().getName());
		lblTotalLoses = new JLabel("Total Loses: " + controller.getPlayer().getLoosers().size());
		lblTotalWIns = new JLabel("Total Wins: " + controller.getPlayer().getWinners().size());
		lblAverageNettedAmount = new JLabel();
		btnSave = new JButton("Save statistics");

		lblTotalWIns.setHorizontalAlignment((int) CENTER_ALIGNMENT);
		lblTotalLoses.setHorizontalAlignment((int) CENTER_ALIGNMENT);
		lblPlayerName.setHorizontalAlignment((int) CENTER_ALIGNMENT);
		lblAverageNettedAmount.setHorizontalAlignment((int) CENTER_ALIGNMENT);

		double totalCredits = 0.0;

		for (int i = 0; i < controller.getGameRecordList().size(); i++) {
			totalCredits += controller.getGameRecordList().get(i);
		}

		controller.setAverageNettedAmount(totalCredits / controller.getGameRecordList().size());
		lblAverageNettedAmount.setText("Average Nett Amount: " + controller.getAverageNettedAmount());

		//  JProgressbar is used here to show average netted amount
		progressBar = new JProgressBar(-100, 100);
		progressBar.setValue((int) Math.round(controller.getAverageNettedAmount()));
		progressBar.setStringPainted(true);

		
		buttonAreaPanel = new JPanel(new FlowLayout());
		displayArePanel = new JPanel(new GridLayout(0, 1));
		panel = new JPanel(new FlowLayout());
		
		displayArePanel.add(lblPlayerName);
		displayArePanel.add(lblTotalWIns);
		displayArePanel.add(lblTotalLoses);
		displayArePanel.add(lblAverageNettedAmount);
		buttonAreaPanel.add(btnSave);
		panel.add(progressBar);

		setComponentFont();
		setComponentPadding();

		add(displayArePanel, BorderLayout.NORTH);
		add(panel, BorderLayout.CENTER);
		add(buttonAreaPanel, BorderLayout.SOUTH);

		setSize(800, 300);
		setLocationRelativeTo(this);//setiting window to the middle
		pack();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	
	private void addListeners() {
		btnSave.addActionListener(event -> {
			controller.saveStatistics();
			JOptionPane.showMessageDialog(this, "Statistics saved!");
		});
	}

		private void setComponentPadding() {
		Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);
		progressBar.setBorder(padding);
		displayArePanel.setBorder(padding);
		buttonAreaPanel.setBorder(padding);

		padding = BorderFactory.createEmptyBorder(0, 30, 5, 30);
		lblPlayerName.setBorder(padding);
		lblTotalWIns.setBorder(padding);
		lblTotalLoses.setBorder(padding);
		lblAverageNettedAmount.setBorder(padding);
	}

	
	private void setComponentFont() {
		Font font = new Font("Calibri", Font.BOLD, 20);

		lblTotalLoses.setFont(font);
		lblTotalWIns.setFont(font);
		lblAverageNettedAmount.setFont(font);
		btnSave.setFont(font);

		font = new Font("Calibri", Font.BOLD, 25);

		lblPlayerName.setFont(font);

		font = new Font("Calibri", Font.BOLD, 15);
		progressBar.setFont(font);
	}

}
