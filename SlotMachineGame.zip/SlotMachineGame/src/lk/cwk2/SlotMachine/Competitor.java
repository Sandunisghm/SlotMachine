package lk.cwk2.SlotMachine;

import java.util.ArrayList;
import java.util.List;



public class Competitor {
	//An instance variable to trigger the player's name
	private String name;
	//An instance variable to trigger credit amount
	private int creditAmount;
	//An instance variable to trigger how much the player has bet 
	private int betAmount;
	private List<Double> winners;
	private List<Double> loosers;

	
	public Competitor(String name) {
		creditAmount = 10;
		this.name = name;
		winners = new ArrayList<Double>();
		loosers = new ArrayList<Double>();
	}

	//all the getters and setters are added
	public int getCredit() {
		return creditAmount;
	}

	public void setCredit(int creditAmount) {
	//each and every player has to add own credits	
		this.creditAmount += creditAmount;
	}

	public List<Double> getWinners() {
		return winners;
	}

	public List<Double> getLoosers() {
		//returning loosers
		return loosers;
	}

	public int getBetAmount() {
		return betAmount;
	}

	public void setBetAmount(int betAmount) {
	//setting bet amount
			this.betAmount += betAmount;
	}

	public String getName() {
		//the name should not be null
		return (name == null || name.equals("")) ? "Not entered" : name;
	}

	public void setName(String name) {
		this.name = name;
	}


}
