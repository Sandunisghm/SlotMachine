package lk.cwk2.SlotMachine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import model.Symbol;

public class Reel {
	private List<Symbol> symbolList;
	//creating a list of symbols

	
	public Reel() {
		
		if (symbolList == null) {
			// checks the availability of symbol list
			symbolList = new ArrayList<Symbol>();
			//initializing an arraylist of symbols
			symbolList.add(new Symbol("redseven.png", 7));
			symbolList.add(new Symbol("bell.png", 6));
			symbolList.add(new Symbol("watermelon.png", 5));
			symbolList.add(new Symbol("plum.png", 4));
			symbolList.add(new Symbol("lemon.png", 3));
			symbolList.add(new Symbol("cherry.png", 2));
			//all these code snippets are for initialize each and every image 
			//and its value
		}
		Collections.shuffle(symbolList);
	}
	public List<Symbol> spin() {
		//getter method of the symbols
		return symbolList;
	}


}
