package lk.cwk2.SlotMachine;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.Border;





public class SlotMachine_Interface extends JFrame {

	private JButton btnReel_1;
	private JButton btnReel_2;
	private JButton btnReel_3;

	private JPanel buttonAreaPanel;
	private JPanel displayArePanel;
	private JPanel reel1Panel;
	private JPanel reel2Panel;
	private JPanel reel3Panel;

	private JButton btnAddCoin;
	private JButton btnBetOne;
	private JButton btnBetMax;
	private JButton btnReset;
	private JButton btnStats;
	private JButton btnNewGame;

	private JLabel lblCreditArea;
	private JLabel lblBetArea;
	private JButton btnSpin;

	private GameController controller;

	private Timer timerReel_1;
	private Timer timerReel_2;
	private Timer timerReel_3;

	private int roundCount1, roundCount2, roundCount3;
	private boolean isSpinning; // to check whether the reels are spinning


	public SlotMachine_Interface() {
		super("Slot Machine Game"); // name of the window
		controller = new GameController(); // initializes the controller


		prepare_GUI();//setting up gui
		addListeners();

		
		String playerName = JOptionPane.showInputDialog(this, "Please Enter your name");
		controller.getPlayer().setName(playerName);
	}

	
	private void prepare_GUI() {
		setLayout(new BorderLayout());

		
		createButtonAreaPannel();
		createReels();
		createDisplayAreaPannel();

		
		setComponentPadding();
		setComponentFont();

		// adding components to the windows's layout
		add(buttonAreaPanel, BorderLayout.NORTH);
		add(reel1Panel, BorderLayout.WEST);
		add(reel2Panel, BorderLayout.CENTER);
		add(reel3Panel, BorderLayout.EAST);
		add(displayArePanel, BorderLayout.SOUTH);

		setSize(900, 700);
		setLocationRelativeTo(null); 
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		pack();//remove spaces
		setVisible(true);
	}

	
	private void addListeners() {
		// listener for the "Statistics" button
		btnStats.addActionListener(event -> {
			// ensures whether the player has played at least one game
			if (controller.getPlayer().getWinners().size() == 0 && controller.getPlayer().getLoosers().size() == 0) {
				showMsgBox("No records are available",
						"You have to try grame for the first time", 0);
			} else {
				new Statistics_Interface(controller.getPlayer()); // displaying the
															// statistics window
			}
		});

		// listener for the "Add Coin" button
		btnAddCoin.addActionListener(event -> updateCreditAndBetLabels(1, 0));

		// listener for the "Bet One" button
		btnBetOne.addActionListener(event -> {
			updateCreditAndBetLabels(0, 1);
		});

		// listener for the "Bet Max" button
		btnBetMax.addActionListener(event -> {
			updateCreditAndBetLabels(0, 3);
		});

		// listener for the "Reset" button
		btnReset.addActionListener(event -> {
			// ensures that the player has bet at least one coin
			if (controller.getPlayer().getBetAmount() != 0) {
				controller.resetBet();
				updateCreditAndBetLabels(0, 0);
			} else {
				showMsgBox("Coin reset Restricted", "You have to put your first bet!", 0);
			}
		});

		// listener for the "New Game" button
		btnNewGame.addActionListener(event -> {
			// setting new plaer's name
			String playerName = JOptionPane.showInputDialog(this, "Please Enter your name");
			controller.startNewGame(playerName);

			// loading the defaults
			updateCreditAndBetLabels(0, 0);
			btnReel_1.setIcon(controller.createIcon("../img/plum.png"));
			btnReel_2.setIcon(controller.createIcon("../img/plum.png"));
			btnReel_3.setIcon(controller.createIcon("../img/plum.png"));
		});

		// listener for the "Spin" button
		btnSpin.addActionListener(event -> beginSpinning());

		// listeners for the three reels
		btnReel_1.addActionListener(event -> stopSpinning(1));
		btnReel_2.addActionListener(event -> stopSpinning(2));
		btnReel_3.addActionListener(event -> stopSpinning(3));

		// listener for the window
		addWindowListener(new WindowAdapter() {

			
			@Override
			public void windowClosing(WindowEvent e) {
			//exit confirmation
				int isConfirmed = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to exit?",
						"Do not you think to keep playing", JOptionPane.YES_NO_OPTION,
						JOptionPane.WARNING_MESSAGE);

				if (isConfirmed == JOptionPane.YES_OPTION) {
					dispose(); // close window object
				}
			}
		});
	}

	
	private void createButtonAreaPannel() {
		buttonAreaPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 10));

		btnAddCoin = new JButton("Add Coin");
		btnBetOne = new JButton("Bet One");
		btnBetMax = new JButton("Bet Max");
		btnReset = new JButton("Reset");
		btnStats = new JButton("Statistics");
		btnNewGame = new JButton("New Game");

		buttonAreaPanel.add(btnAddCoin);
		buttonAreaPanel.add(btnBetOne);
		buttonAreaPanel.add(btnBetMax);
		buttonAreaPanel.add(btnReset);
		buttonAreaPanel.add(btnStats);
		buttonAreaPanel.add(btnNewGame);
	}

	// Creating separately driven image reels
	private void createReels() {
		//initializing new 3 reel objects
		reel1Panel = new JPanel(new FlowLayout());
		reel2Panel = new JPanel(new FlowLayout());
		reel3Panel = new JPanel(new FlowLayout());

		btnReel_1 = new JButton();
		btnReel_2 = new JButton();
		btnReel_3 = new JButton();

		//Setting images to the reels
		btnReel_1.setIcon(controller.createIcon("../img/plum.png"));
		btnReel_2.setIcon(controller.createIcon("../img/plum.png"));
		btnReel_3.setIcon(controller.createIcon("../img/plum.png"));
		//developing User interface
		btnReel_1.setBackground(Color.DARK_GRAY);
		btnReel_2.setBackground(Color.DARK_GRAY);
		btnReel_3.setBackground(Color.DARK_GRAY);
		//adding reels to the reel panel
		reel1Panel.add(btnReel_1);
		reel2Panel.add(btnReel_2);
		reel3Panel.add(btnReel_3);
	}

	
	private void createDisplayAreaPannel() {
		displayArePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 150, 10));

		lblCreditArea = new JLabel("Credit Area: 10");
		lblBetArea = new JLabel("Bet Area: 0");
		btnSpin = new JButton("Spin");

		displayArePanel.add(lblCreditArea);
		displayArePanel.add(btnSpin);
		displayArePanel.add(lblBetArea);
		displayArePanel.setBackground(Color.lightGray);/////
		buttonAreaPanel.setBackground(Color.lightGray);

	}

	
	private void setComponentPadding() {
		Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);
		reel1Panel.setBorder(padding);
		reel2Panel.setBorder(padding);
		reel3Panel.setBorder(padding);

		displayArePanel.setBorder(padding);
		buttonAreaPanel.setBorder(padding);
		
	}

	
	private void setComponentFont() {
		Font font = new Font("Calibri", Font.BOLD, 30);

		btnAddCoin.setFont(font);
		btnBetOne.setFont(font);
		btnBetMax.setFont(font);
		btnReset.setFont(font);
		btnStats.setFont(font);
		btnNewGame.setFont(font);
		btnSpin.setFont(font);
		btnSpin.setBackground(Color.RED);

		font = new Font("Calibri", Font.BOLD, 35);

		lblCreditArea.setFont(font);
		lblBetArea.setFont(font);

		font = new Font("Arial", Font.PLAIN, 15);

		UIManager.put("OptionPane.buttonFont", font);
		UIManager.put("OptionPane.messageFont", font);
	}

	private void beginSpinning() {
		
		if (controller.getPlayer().getBetAmount() > 0 && !isSpinning) {

			// setting to default values
			roundCount1 = 0;
			roundCount2 = 0;
			roundCount3 = 0;
			isSpinning = true;

			
			controller.reelThread1 = new Thread(() -> {
				// defining the Swing timer
				timerReel_1 = new Timer(100, event -> { 
					btnReel_1.setIcon(// changing the symbol
							controller.createIcon(controller.reelList.get(0).spin().get(roundCount1).getImage()));

					
					controller.setCurrentSymbol_reel1(controller.reelList.get(0).spin().get(roundCount1));
					
					if (roundCount1 == controller.reelList.get(0).spin().size() - 1) {
						roundCount1 = 0;
					} else {
						roundCount1++;
					}
				});

				//remove initial delays
				timerReel_1.setInitialDelay(0);
				timerReel_1.start();
			});
			controller.reelThread1.start(); //new thread will get started

			controller.reelThread2 = new Thread(() -> {
				timerReel_2 = new Timer(100, event -> {
					btnReel_2.setIcon(
							controller.createIcon(controller.reelList.get(1).spin().get(roundCount2).getImage()));
					controller.setCurrentSymbol_reel2(controller.reelList.get(1).spin().get(roundCount2));
					if (roundCount2 == controller.reelList.get(1).spin().size() - 1) {
						roundCount2 = 0;
					} else {
						roundCount2++;
					}
				});
				timerReel_2.setInitialDelay(0);
				timerReel_2.start();
			});
			controller.reelThread2.start();

			controller.reelThread3 = new Thread(() -> {
				timerReel_3 = new Timer(100, event -> {
					btnReel_3.setIcon(
							controller.createIcon(controller.reelList.get(2).spin().get(roundCount3).getImage()));
					controller.setCurrentSymbol_reel3(controller.reelList.get(2).spin().get(roundCount3));
					if (roundCount3 == controller.reelList.get(2).spin().size() - 1) {
						roundCount3 = 0;
					} else {
						roundCount3++;
					}
				});
				timerReel_3.setInitialDelay(0);
				timerReel_3.start();
			});
			controller.reelThread3.start();
		} else {
			
			if (isSpinning) {
				showMsgBox("Unable to perform this action", "The reels are already spinning!", 0);
			} else {
				showMsgBox("Empty Bet Area", "You must bet at least 1 coin to play the game!", 0);
			}
		}
	}

	//stop spin 
	private void stopSpinning(int reelNo) {
		if (isSpinning) { // checks if that reel has already stopped
			try {
				if (reelNo == 1) {
					timerReel_1.stop();
				} else if (reelNo == 2) {
					timerReel_2.stop();
				} else if (reelNo == 3) {
					timerReel_3.stop();
				}

				// check whether all the threads are in spinning state
				if (!timerReel_1.isRunning() && !timerReel_2.isRunning() && !timerReel_3.isRunning()) {
					try {
				// wait until spinning threads  get finished execution
						controller.reelThread1.join();
						controller.reelThread2.join();
						controller.reelThread3.join();
					} catch (InterruptedException e) {
						e.printStackTrace();
					} finally {
						
						int wonCredits = controller.saveGameResult();
						if (wonCredits > 0) {    // winning game
							showMsgBox("Congratulations", "You won " + wonCredits + " credits!", 1);
						} else if (wonCredits == 0)  { // lost game
							showMsgBox("Game over", "You lost! Try again.", 1);
						}else{ // tied game
							wonCredits = 0;
							showMsgBox("Congratulations", "You won, but only two symbols matched!, You can spin again. ", 1);
						}
						updateCreditAndBetLabels(wonCredits, 0);
						isSpinning = false;
					}
				}
			} catch (NullPointerException e) {
				
				showMsgBox("Problem encountered", "You haven't started spinning the reels yet!", 2);
			}
		}

	}

	
	private void updateCreditAndBetLabels(int creditAmount, int betAmount) {
		lblBetArea.setText("Bet Area: " + controller.addBet(betAmount));
		lblCreditArea.setText("Credit Area: " + controller.addCoin(creditAmount));
	}

	
	private void showMsgBox(String title, String message, int messageType) {
		switch (messageType) {
		case 1:
			messageType = JOptionPane.INFORMATION_MESSAGE;
			break;
		case 2:
			messageType = JOptionPane.WARNING_MESSAGE;
			break;
		default:
			messageType = JOptionPane.ERROR_MESSAGE;
			break;
		}
		JOptionPane.showMessageDialog(this, message, title, messageType);
	}
}
