package lk.cwk2.SlotMachine;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



public class Statistics {
	private Competitor competitor;
	private List<Double> gameRecord;
	private double netAmount;

	
	public Statistics(Competitor competitor) {
		this.competitor = competitor;
		gameRecord = new ArrayList<Double>(); //a list of the whole game
		gameRecord.addAll(competitor.getWinners());
		gameRecord.addAll(competitor.getLoosers());
		netAmount = 0;
	}

	
	public void saveStatistics() {
		try (FileWriter fw = new FileWriter(LocalDate.now() + ".txt", true)){
			//creating text file for the day at the first time of
			//saving statistics			
			PrintWriter pw = new PrintWriter(fw);
			// updating the text file
			pw.println("Name: " + competitor.getName());
			pw.println("Total Wins: " + competitor.getWinners().size());
			pw.println("Total Loses: " + competitor.getLoosers().size());
			pw.println("Average Netted Amount: " + getAverageNettedAmount());
			pw.println("___________________________________________________");
			pw.println();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// getter method of the player
	public Competitor getPlayer() {
		return competitor;
	}

	
	public List<Double> getGameRecordList() {
		return gameRecord;
	}

	public double getAverageNettedAmount() {
		return netAmount;
	}

	public void setAverageNettedAmount(double netAmount) {
		this.netAmount = netAmount;
	}


}
