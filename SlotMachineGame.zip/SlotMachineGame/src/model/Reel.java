package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Reel {
	private List<Symbol> symbolList;

	public Reel() {
		if(symbolList == null){
			symbolList = new ArrayList<Symbol>();

			symbolList.add(new Symbol("redseven.png", 7));
			symbolList.add(new Symbol("bell.png", 6));
			symbolList.add(new Symbol("watermelon.png", 5));
			symbolList.add(new Symbol("plum.png", 4));
			symbolList.add(new Symbol("lemon.png", 3));
			symbolList.add(new Symbol("cherry.png", 2));
		}

		Collections.shuffle(symbolList);
	}

	public List<Symbol> spin() {
		return symbolList;
	}

}
