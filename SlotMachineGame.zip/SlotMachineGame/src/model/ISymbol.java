package model;

public interface ISymbol {
	void setImage(String imageName);

	String getImage();

	void setValue(int v);

	int getValue();
}
