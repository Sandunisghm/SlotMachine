package model;

public class Symbol implements ISymbol {
	private String imagePath;
	private int value;

	public Symbol(String imageName, int value) {
		imagePath = "../img/" + imageName;
		this.value = value;
	}

	@Override
	public void setImage(String imageName) {
		imagePath = "../img/" + imageName;
	}

	@Override
	public String getImage() {
		return imagePath;
	}

	@Override
	public void setValue(int v) {
		value = v;

	}

	@Override
	public int getValue() {
		return value;
	}

	public int[] compareValues(Symbol rhs) {
		int[] result = new int[2];
		result[1] = value;
		if (this.value == rhs.getValue()) {
			result[0] = 1;
		} else {
			result[0] = 0;
		}
		return result;
	}

}
